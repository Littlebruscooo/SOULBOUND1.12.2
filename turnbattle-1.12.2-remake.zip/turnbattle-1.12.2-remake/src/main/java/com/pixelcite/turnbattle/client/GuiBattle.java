package com.pixelcite.turnbattle.client;

import com.pixelcite.turnbattle.ModSounds;
import com.pixelcite.turnbattle.SoulType;
import com.pixelcite.turnbattle.TurnBattleMod;
import com.pixelcite.turnbattle.net.Net;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EntityList;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

/**
 * The battle screen: a menu (FIGHT / ACT / ITEM / MERCY), an attack-timing bar, and a bullet-dodging phase.
 * Controls: arrows or WASD to move, Enter / Z / Space to confirm, X / Backspace to go back, Shift to move slowly.
 */
@SideOnly(Side.CLIENT)
public class GuiBattle extends GuiScreen {
    private enum S { MENU, FIGHT, ACT, ITEM, MERCY, WAIT, TEXT, DODGE }

    private static final String[] BUTTON_TEX = {"bash", "defend", "goods", "mercy"};
    private static final String[] ACT_ITEMS = {"Check", "Cheer", "Guard"};
    private static final String[] MERCY_ITEMS = {"Spare", "Flee"};

    // ---- battle data (mirrors the server) ----
    private final int mobId;
    private final String mobName;
    private final String mobKey;
    private final SoulType soul;
    private float mobHp, mobMax, hp, hpMax;
    private int mercy;

    // ---- ui state ----
    private S state = S.TEXT;
    private S afterText = S.MENU;
    private boolean closeAfterText;
    private String text;
    private int sel;           // main menu index
    private int sub;           // submenu index
    private final List<String> subItems = new ArrayList<>();
    private final List<Integer> itemSlots = new ArrayList<>();
    private long last = System.nanoTime();
    private long shakeUntil, openedAt = System.currentTimeMillis();
    private BattleMusic music;
    private boolean started;

    // ---- fight bar ----
    private float cursor;
    private long slashStart;

    // ---- dodge phase ----
    private Net.Update dodgeParams;
    private final List<float[]> bullets = new ArrayList<>(); // x, y, vx, vy
    private Random rng = new Random();
    private float sx, sy, spawnAcc, spiral, elapsedMs, invulnMs;
    private int hits;

    private static final Map<String, int[]> SIZE_CACHE = new HashMap<>();

    public GuiBattle(Net.Open m) {
        this.mobId = m.mobId;
        this.mobHp = m.mobHp;
        this.mobMax = m.mobMax;
        this.hp = m.hp;
        this.hpMax = m.hpMax;
        this.mercy = m.mercy;
        this.soul = SoulType.byOrdinal(m.soul);
        Entity e = Minecraft.getMinecraft().world.getEntityByID(m.mobId);
        this.mobName = e != null ? e.getName() : "Monster";
        ResourceLocation key = e != null ? EntityList.getKey(e) : null;
        this.mobKey = key != null ? key.getResourcePath() : "";
        this.text = "* " + mobName + " draws near!";
    }

    // ================================================================== lifecycle

    @Override
    public void initGui() {
        if (!started) {
            started = true;
            music = new BattleMusic(ModSounds.MUS_BATTLE);
            mc.getSoundHandler().playSound(music);
            sfx(ModSounds.BATTLE_START);
        }
    }

    @Override
    public void onGuiClosed() {
        if (music != null) mc.getSoundHandler().stopSound(music);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    /** Called when the server answers an action or ends the battle. */
    public void onUpdate(Net.Update u) {
        if (u.mobHp < mobHp - 0.001f) {
            shakeUntil = System.currentTimeMillis() + 450;
            sfx(ModSounds.DAMAGE);
        }
        mobHp = u.mobHp;
        if (u.hp < hp - 0.001f) sfx(ModSounds.HURT);
        hp = u.hp;
        hpMax = u.hpMax;
        if (u.mercy > mercy) sfx(ModSounds.MERCY);
        mercy = u.mercy;
        text = u.text;
        closeAfterText = false;
        switch (u.kind) {
            case Net.Update.MENU:
                state = S.TEXT;
                afterText = S.MENU;
                break;
            case Net.Update.DODGE:
                dodgeParams = u;
                state = S.TEXT;
                afterText = S.DODGE;
                break;
            case Net.Update.WON:
                sfx(ModSounds.LEVEL_UP);
                state = S.TEXT;
                closeAfterText = true;
                break;
            case Net.Update.SPARED:
            case Net.Update.FLED:
            case Net.Update.LOST:
                state = S.TEXT;
                closeAfterText = true;
                break;
            default: // ABORT
                mc.displayGuiScreen(null);
        }
    }

    // ================================================================== input

    private static boolean isConfirm(int k) {
        return k == Keyboard.KEY_RETURN || k == Keyboard.KEY_Z || k == Keyboard.KEY_SPACE || k == Keyboard.KEY_NUMPADENTER;
    }

    private static boolean isBack(int k) {
        return k == Keyboard.KEY_X || k == Keyboard.KEY_BACK || k == Keyboard.KEY_ESCAPE;
    }

    @Override
    protected void keyTyped(char c, int k) throws IOException {
        // Escape never closes the screen; use MERCY > Flee instead.
        switch (state) {
            case TEXT:
                if (isConfirm(k)) advanceText();
                break;
            case MENU:
                if (k == Keyboard.KEY_LEFT || k == Keyboard.KEY_A) { sel = (sel + 3) % 4; sfx(ModSounds.MENU_MOVE); }
                else if (k == Keyboard.KEY_RIGHT || k == Keyboard.KEY_D) { sel = (sel + 1) % 4; sfx(ModSounds.MENU_MOVE); }
                else if (isConfirm(k)) openMenu(sel);
                break;
            case ACT:
            case ITEM:
            case MERCY:
                if (k == Keyboard.KEY_UP || k == Keyboard.KEY_W) { sub = (sub + subItems.size() - 1) % subItems.size(); sfx(ModSounds.MENU_MOVE); }
                else if (k == Keyboard.KEY_DOWN || k == Keyboard.KEY_S) { sub = (sub + 1) % subItems.size(); sfx(ModSounds.MENU_MOVE); }
                else if (isBack(k)) { state = S.MENU; sfx(ModSounds.MENU_MOVE); }
                else if (isConfirm(k)) confirmSub();
                break;
            case FIGHT:
                if (isConfirm(k)) strike();
                break;
            default:
                break;
        }
    }

    @Override
    protected void mouseClicked(int mx, int my, int button) throws IOException {
        if (button != 0) return;
        if (state == S.MENU) {
            for (int i = 0; i < 4; i++) {
                int[] r = buttonRect(i);
                if (mx >= r[0] && mx <= r[0] + r[2] && my >= r[1] && my <= r[1] + r[3]) {
                    if (sel == i) openMenu(i); else { sel = i; sfx(ModSounds.MENU_MOVE); }
                    return;
                }
            }
        } else if (state == S.TEXT) {
            advanceText();
        } else if (state == S.FIGHT) {
            strike();
        } else if (state == S.ACT || state == S.ITEM || state == S.MERCY) {
            int x = boxX() + 24, y = top() + 8;
            for (int i = 0; i < subItems.size(); i++) {
                if (mx >= x && mx <= x + 120 && my >= y + i * 12 && my <= y + i * 12 + 11) {
                    if (sub == i) confirmSub(); else { sub = i; sfx(ModSounds.MENU_MOVE); }
                    return;
                }
            }
        }
    }

    private void advanceText() {
        sfx(ModSounds.SELECT);
        if (closeAfterText) { mc.displayGuiScreen(null); return; }
        state = afterText;
        if (state == S.DODGE) startDodge();
        else if (state == S.MENU) text = "* What will you do?";
    }

    private void openMenu(int i) {
        sfx(ModSounds.SELECT);
        sub = 0;
        subItems.clear();
        itemSlots.clear();
        switch (i) {
            case 0:
                cursor = 0f;
                state = S.FIGHT;
                break;
            case 1:
                for (String s : ACT_ITEMS) subItems.add(s);
                state = S.ACT;
                break;
            case 2:
                for (int s = 0; s < mc.player.inventory.getSizeInventory(); s++) {
                    ItemStack st = mc.player.inventory.getStackInSlot(s);
                    if (!st.isEmpty() && st.getItem() instanceof ItemFood) {
                        subItems.add(st.getDisplayName() + " x" + st.getCount());
                        itemSlots.add(s);
                    }
                }
                if (subItems.isEmpty()) { text = "* You have no food."; return; }
                state = S.ITEM;
                break;
            default:
                for (String s : MERCY_ITEMS) subItems.add(s);
                state = S.MERCY;
        }
    }

    private void confirmSub() {
        sfx(ModSounds.SELECT);
        if (state == S.ACT) {
            send(Net.Action.CHECK + sub, 0f, 0);
        } else if (state == S.ITEM) {
            send(Net.Action.ITEM, 0f, itemSlots.get(sub));
        } else if (state == S.MERCY) {
            send(sub == 0 ? Net.Action.SPARE : Net.Action.FLEE, 0f, 0);
        }
    }

    private void strike() {
        float acc = 1f - Math.abs(cursor - 0.5f) * 2f;
        slashStart = System.currentTimeMillis();
        sfx(ModSounds.SLASH);
        send(Net.Action.FIGHT, Math.max(0f, acc), 0);
    }

    private void send(int type, float acc, int slot) {
        TurnBattleMod.NET.sendToServer(new Net.Action(type, acc, slot));
        state = S.WAIT;
        text = "...";
    }

    // ================================================================== layout helpers

    private int top() { return (int) (height * 0.50f); }
    private int bottom() { return height - 42; }
    private int boxX() { return width / 2 - 130; }
    private int boxW() { return 260; }
    private int dodgeSize() { return Math.max(60, Math.min(110, bottom() - top())); }

    private int[] buttonRect(int i) {
        int w = 62, h = 26;
        int total = w * 4 + 6 * 3;
        int x = width / 2 - total / 2 + i * (w + 6);
        return new int[]{x, height - 36, w, h};
    }

    // ================================================================== draw

    @Override
    public void drawScreen(int mx, int my, float pt) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        update(dt);

        // background
        int bg = 1 + Math.floorMod(mobId * 31 + mc.player.dimension, 100);
        image(tex("battle_bg/bbs_" + bg), 0, 0, width, height);
        drawRect(0, 0, width, height, 0xAA000000);

        drawMob();
        drawEnemyBars();
        drawPanel();
        drawButtons();
        drawPlayerBar();
    }

    private void update(float dt) {
        if (state == S.FIGHT) {
            cursor += dt * (soul == SoulType.BRAVERY ? 0.8f : 1.1f);
            if (cursor >= 1f) { cursor = 1f; send(Net.Action.FIGHT, 0f, 0); }
        } else if (state == S.DODGE) {
            tickDodge(dt * 1000f);
        }
    }

    private void drawMob() {
        long nowMs = System.currentTimeMillis();
        int cx = width / 2;
        int baseY = (int) (height * 0.40f);
        int shake = nowMs < shakeUntil ? (int) (Math.sin(nowMs * 0.08) * 5) : 0;

        // try a portrait frame first, then fall back to rendering the real mob
        int frame = ((nowMs - openedAt) / 500) % 2 == 0 ? 1 : 2;
        ResourceLocation portrait = tex("mob_portraits/" + mobKey + frame);
        int[] dim = size(portrait);
        if (dim == null) { portrait = tex("mob_portraits/" + mobKey + "1"); dim = size(portrait); }
        if (dim != null) {
            float h = height * 0.30f;
            float w = h * dim[0] / dim[1];
            image(portrait, cx - w / 2 + shake, baseY - h, w, h);
        } else {
            Entity e = mc.world.getEntityByID(mobId);
            if (e instanceof EntityLivingBase) {
                GuiInventory.drawEntityOnScreen(cx + shake, baseY, Math.max(20, (int) (height * 0.10f)), 0, 0, (EntityLivingBase) e);
            }
        }
        // slash effect
        long since = nowMs - slashStart;
        if (slashStart > 0 && since < 420) {
            int f = 1 + (int) (since / 70);
            if (f > 6) f = 6;
            float h = height * 0.34f, w = h * 26f / 110f;
            image(tex("effects/slash" + f), cx - w / 2, baseY - h, w, h);
        }
        GlStateManager.disableBlend();
    }

    private void drawEnemyBars() {
        int w = 150, x = width / 2 - w / 2, y = 12;
        fontRenderer.drawStringWithShadow(mobName, x, y - 2, 0xFFFFFF);
        drawRect(x, y + 9, x + w, y + 15, 0xFF550000);
        drawRect(x, y + 9, x + (int) (w * Math.max(0, mobHp) / Math.max(1, mobMax)), y + 15, 0xFFFF3030);
        fontRenderer.drawStringWithShadow(String.format("%.0f/%.0f", Math.max(0, mobHp), mobMax), x + w + 4, y + 8, 0xFFFFFF);
        drawRect(x, y + 18, x + w, y + 22, 0xFF444400);
        drawRect(x, y + 18, x + (int) (w * mercy / 100f), y + 22, 0xFFFFFF40);
        fontRenderer.drawStringWithShadow("Mercy " + mercy + "%", x + w + 4, y + 16, 0xFFFF80);
    }

    private void drawPlayerBar() {
        int w = 120, x = width / 2 - w / 2, y = height - 9;
        drawRect(x, y, x + w, y + 5, 0xFF550000);
        drawRect(x, y, x + (int) (w * Math.max(0, hp) / Math.max(1, hpMax)), y + 5, 0xFFFFE030);
        fontRenderer.drawStringWithShadow(String.format("HP %.0f/%.0f", Math.max(0, hp), hpMax), x + w + 4, y - 2, 0xFFFFFF);
        if (soul != null) fontRenderer.drawStringWithShadow(soul.id.toUpperCase(), x - fontRenderer.getStringWidth(soul.id) - 8, y - 2, 0xFFFFFF);
    }

    private void drawButtons() {
        for (int i = 0; i < 4; i++) {
            int[] r = buttonRect(i);
            boolean on = sel == i && state == S.MENU || (state == S.FIGHT && i == 0) || (state == S.ACT && i == 1)
                    || (state == S.ITEM && i == 2) || (state == S.MERCY && i == 3);
            String n = BUTTON_TEX[i] + (on ? "sel" : "");
            int hh = on ? 32 : 26;
            image(tex("gui/" + n), r[0], r[1] - (on ? 6 : 0), r[2], r[3] * hh / 26f);
        }
        GlStateManager.disableBlend();
    }

    private void box(int x, int y, int w, int h) {
        drawRect(x - 2, y - 2, x + w + 2, y + h + 2, 0xFFFFFFFF);
        drawRect(x, y, x + w, y + h, 0xFF000000);
    }

    private void drawPanel() {
        int y = top(), h = bottom() - top();
        if (state == S.DODGE) { drawDodge(); return; }
        int x = boxX(), w = boxW();
        box(x, y, w, h);
        switch (state) {
            case TEXT:
            case MENU:
            case WAIT: {
                int ly = y + 8;
                for (String para : text.split("\n")) {
                    for (Object line : fontRenderer.listFormattedStringToWidth(para, w - 16)) {
                        fontRenderer.drawString((String) line, x + 8, ly, 0xFFFFFF);
                        ly += 11;
                    }
                }
                if (state == S.TEXT) fontRenderer.drawString("[Enter]", x + w - 44, y + h - 12, 0x808080);
                else if (state == S.MENU) fontRenderer.drawString("Arrows/WASD + Enter. Sneak-hit = normal combat.", x + 8, y + h - 12, 0x606060);
                break;
            }
            case FIGHT: {
                int bx = x + 10, bw = w - 20, by = y + h / 2 - 8;
                drawRect(bx, by, bx + bw, by + 16, 0xFF303030);
                drawRect(bx + (int) (bw * 0.40f), by, bx + (int) (bw * 0.60f), by + 16, 0xFF30A030);
                drawRect(bx + (int) (bw * 0.47f), by, bx + (int) (bw * 0.53f), by + 16, 0xFFE0E030);
                int cxp = bx + (int) (bw * cursor);
                drawRect(cxp - 1, by - 5, cxp + 2, by + 21, 0xFFFFFFFF);
                fontRenderer.drawString("Press Enter / Z / click to strike. Aim for the middle!", x + 8, y + 8, 0xFFFFFF);
                break;
            }
            default: { // submenus
                int ly = y + 8;
                for (int i = 0; i < subItems.size(); i++) {
                    fontRenderer.drawString(subItems.get(i), x + 24, ly + i * 12, i == sub ? 0xFFFF00 : 0xFFFFFF);
                }
                SoulType s = soul != null ? soul : SoulType.DETERMINATION;
                image(tex("souls/" + s.texture), x + 10, ly + sub * 12 + 1, 9, 9);
                GlStateManager.disableBlend();
                break;
            }
        }
    }

    // ================================================================== dodge phase

    private void startDodge() {
        bullets.clear();
        rng = new Random(dodgeParams.seed);
        int s = dodgeSize();
        sx = s / 2f;
        sy = s * 0.75f;
        spawnAcc = 0f;
        spiral = 0f;
        elapsedMs = 0f;
        invulnMs = 0f;
        hits = 0;
        state = S.DODGE;
    }

    private void tickDodge(float dtMs) {
        int s = dodgeSize();
        float k = s / 100f;
        float dt = dtMs / 1000f;

        // movement
        float dx = 0, dy = 0;
        if (Keyboard.isKeyDown(Keyboard.KEY_LEFT) || Keyboard.isKeyDown(Keyboard.KEY_A)) dx -= 1;
        if (Keyboard.isKeyDown(Keyboard.KEY_RIGHT) || Keyboard.isKeyDown(Keyboard.KEY_D)) dx += 1;
        if (Keyboard.isKeyDown(Keyboard.KEY_UP) || Keyboard.isKeyDown(Keyboard.KEY_W)) dy -= 1;
        if (Keyboard.isKeyDown(Keyboard.KEY_DOWN) || Keyboard.isKeyDown(Keyboard.KEY_S)) dy += 1;
        if (dx != 0 && dy != 0) { dx *= 0.7071f; dy *= 0.7071f; }
        float speed = 75f * k * (Keyboard.isKeyDown(Keyboard.KEY_LSHIFT) ? 0.5f : 1f);
        sx = Math.max(4 * k, Math.min(s - 4 * k, sx + dx * speed * dt));
        sy = Math.max(4 * k, Math.min(s - 4 * k, sy + dy * speed * dt));

        // spawning
        float sm = dodgeParams.speedMul;
        int interval = new int[]{170, 260, 650, 90}[dodgeParams.pattern];
        spawnAcc += dtMs;
        while (spawnAcc >= interval) {
            spawnAcc -= interval;
            spawnBullet(s, k, sm);
        }

        // move bullets, collide
        invulnMs = Math.max(0f, invulnMs - dtMs);
        float hitR = 3.6f * k + 3f * k;
        for (int i = bullets.size() - 1; i >= 0; i--) {
            float[] b = bullets.get(i);
            b[0] += b[2] * dt;
            b[1] += b[3] * dt;
            if (b[0] < -20 || b[1] < -20 || b[0] > s + 20 || b[1] > s + 20) { bullets.remove(i); continue; }
            float ddx = b[0] - sx, ddy = b[1] - sy;
            if (invulnMs <= 0f && ddx * ddx + ddy * ddy < hitR * hitR) {
                hits++;
                invulnMs = 1000f;
                sfx(ModSounds.HURT);
            }
        }

        elapsedMs += dtMs;
        if (elapsedMs >= dodgeParams.durMs) {
            TurnBattleMod.NET.sendToServer(new Net.Dodge(hits));
            state = S.WAIT;
            text = "...";
            bullets.clear();
        }
    }

    private void spawnBullet(int s, float k, float sm) {
        switch (dodgeParams.pattern) {
            case 0: // rain
                bullets.add(new float[]{rng.nextFloat() * s, -6, 0, 62 * k * sm});
                break;
            case 1: { // side sweeps
                boolean left = rng.nextBoolean();
                bullets.add(new float[]{left ? -6 : s + 6, rng.nextFloat() * s, (left ? 1 : -1) * 72 * k * sm, 0});
                break;
            }
            case 2: { // aimed from a random edge
                float ex, ey;
                int edge = rng.nextInt(4);
                if (edge == 0) { ex = rng.nextFloat() * s; ey = -6; }
                else if (edge == 1) { ex = rng.nextFloat() * s; ey = s + 6; }
                else if (edge == 2) { ex = -6; ey = rng.nextFloat() * s; }
                else { ex = s + 6; ey = rng.nextFloat() * s; }
                float ax = sx - ex, ay = sy - ey, len = (float) Math.sqrt(ax * ax + ay * ay);
                if (len < 1) len = 1;
                bullets.add(new float[]{ex, ey, ax / len * 78 * k * sm, ay / len * 78 * k * sm});
                break;
            }
            default: { // spiral from the middle
                spiral += 0.55f;
                bullets.add(new float[]{s / 2f, s / 2f, (float) Math.cos(spiral) * 46 * k * sm, (float) Math.sin(spiral) * 46 * k * sm});
            }
        }
    }

    private void drawDodge() {
        int s = dodgeSize();
        int x = width / 2 - s / 2, y = top() + (bottom() - top() - s) / 2;
        box(x, y, s, s);

        ScaledResolution sr = new ScaledResolution(mc);
        int f = sr.getScaleFactor();
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor(x * f, mc.displayHeight - (y + s) * f, s * f, s * f);
        float k = s / 100f;
        for (float[] b : bullets) {
            float d = 10 * k;
            image(tex("gui/bullet"), x + b[0] - d / 2, y + b[1] - d / 2, d, d);
        }
        boolean show = invulnMs <= 0f || ((int) (invulnMs / 90)) % 2 == 0;
        if (show) {
            SoulType st = soul != null ? soul : SoulType.DETERMINATION;
            float d = 9 * k;
            image(tex("souls/" + st.texture), x + sx - d / 2, y + sy - d / 2, d, d);
        }
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
        GlStateManager.disableBlend();

        int secs = Math.max(0, (int) Math.ceil((dodgeParams.durMs - elapsedMs) / 1000f));
        fontRenderer.drawStringWithShadow("Dodge! " + secs + "s", x, y - 11, 0xFFFFFF);
    }

    // ================================================================== rendering helpers

    private static ResourceLocation tex(String path) {
        return new ResourceLocation(TurnBattleMod.MODID, "textures/" + path + ".png");
    }

    /** Pixel size of a texture, or null when it does not exist. */
    private int[] size(ResourceLocation rl) {
        String key = rl.toString();
        if (SIZE_CACHE.containsKey(key)) return SIZE_CACHE.get(key);
        int[] r = null;
        try (InputStream in = mc.getResourceManager().getResource(rl).getInputStream()) {
            BufferedImage img = TextureUtil.readBufferedImage(in);
            r = new int[]{img.getWidth(), img.getHeight()};
        } catch (IOException ignored) {
            // missing texture: caller falls back
        }
        SIZE_CACHE.put(key, r);
        return r;
    }

    /** Draws a whole texture into a float rectangle with crisp pixels. */
    private void image(ResourceLocation rl, float x, float y, float w, float h) {
        mc.getTextureManager().bindTexture(rl);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_NEAREST);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_NEAREST);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA,
                GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.color(1f, 1f, 1f, 1f);
        Tessellator t = Tessellator.getInstance();
        BufferBuilder bb = t.getBuffer();
        bb.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_TEX);
        bb.pos(x, y + h, 0).tex(0, 1).endVertex();
        bb.pos(x + w, y + h, 0).tex(1, 1).endVertex();
        bb.pos(x + w, y, 0).tex(1, 0).endVertex();
        bb.pos(x, y, 0).tex(0, 0).endVertex();
        t.draw();
    }

    private void sfx(SoundEvent e) {
        mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(e, 1.0F));
    }
}
