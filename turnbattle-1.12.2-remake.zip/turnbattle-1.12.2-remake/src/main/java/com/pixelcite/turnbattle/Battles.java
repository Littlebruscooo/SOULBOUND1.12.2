package com.pixelcite.turnbattle;

import com.pixelcite.turnbattle.net.Net;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;

/** Server-side battle state machine. The server owns HP, mercy and damage; the client only reports timing and hits. */
public final class Battles {
    private Battles() {}

    /** Set while the battle itself damages the player, so the "untouchable in battle" rule lets it through. */
    public static boolean applying = false;

    private static final Map<UUID, Battle> ACTIVE = new HashMap<>();
    private static final Map<String, Long> SPARED = new HashMap<>();   // "player:mob" -> world time it expires
    private static final Map<UUID, Long> COOLDOWN = new HashMap<>();    // player -> world time a new battle may start

    private static final int SPARE_TICKS = 2400;   // spared mobs leave you alone for two minutes
    private static final int COOLDOWN_TICKS = 100; // 5 seconds before another battle can start
    private static final int ENEMY_BASE_MS = 6000;

    private static final class Battle {
        EntityPlayerMP player;
        EntityLiving mob;
        boolean mobWasNoAI;
        int mercy, turn;
        boolean guard, awaitingDodge;
        float perHit;
    }

    // ------------------------------------------------------------------ queries

    public static boolean inBattle(EntityPlayerMP p) {
        return ACTIVE.containsKey(p.getUniqueID());
    }

    public static boolean isSpared(EntityPlayerMP p, Entity mob) {
        Long until = SPARED.get(p.getUniqueID() + ":" + mob.getUniqueID());
        return until != null && until > p.world.getTotalWorldTime();
    }

    public static boolean eligible(EntityPlayerMP p, Entity t) {
        if (!(t instanceof EntityLiving) || !(t instanceof IMob) || !t.isNonBoss() || t.isDead) return false;
        if (((EntityLiving) t).getHealth() <= 0) return false;
        Long cd = COOLDOWN.get(p.getUniqueID());
        if (cd != null && cd > p.world.getTotalWorldTime()) return false;
        for (Battle b : ACTIVE.values()) if (b.mob == t) return false;
        return true;
    }

    // ------------------------------------------------------------------ lifecycle

    public static void start(EntityPlayerMP p, EntityLiving mob) {
        Battle b = new Battle();
        b.player = p;
        b.mob = mob;
        b.mobWasNoAI = mob.isAIDisabled();
        mob.setNoAI(true);
        mob.setAttackTarget(null);
        ACTIVE.put(p.getUniqueID(), b);
        SoulType soul = SoulItem.getSoul(p);
        TurnBattleMod.NET.sendTo(new Net.Open(mob.getEntityId(), mob.getHealth(), mob.getMaxHealth(),
                p.getHealth(), p.getMaxHealth(), soul == null ? -1 : soul.ordinal(), 0), p);
    }

    /** Ends a battle. If {@code notify}, the client is told to close its screen. */
    public static void abort(EntityPlayerMP p, boolean notify) {
        Battle b = ACTIVE.remove(p.getUniqueID());
        if (b == null) return;
        release(b);
        if (notify) TurnBattleMod.NET.sendTo(new Net.Update(Net.Update.ABORT, "", 0, p.getHealth(), p.getMaxHealth(), 0), p);
    }

    private static void release(Battle b) {
        if (!b.mob.isDead && !b.mobWasNoAI) b.mob.setNoAI(false);
        COOLDOWN.put(b.player.getUniqueID(), b.player.world.getTotalWorldTime() + COOLDOWN_TICKS);
    }

    /** Drops all battle state, e.g. when the server stops (the integrated server keeps statics alive between worlds). */
    public static void clear() {
        for (Battle b : new ArrayList<>(ACTIVE.values())) release(b);
        ACTIVE.clear();
        SPARED.clear();
        COOLDOWN.clear();
    }

    public static void tick() {
        if (ACTIVE.isEmpty()) return;
        for (Battle b : new ArrayList<>(ACTIVE.values())) {
            EntityPlayerMP p = b.player;
            boolean bad = p.isDead || p.getHealth() <= 0 || b.mob.isDead || b.mob.world != p.world
                    || p.getDistanceSq(b.mob) > 40 * 40;
            if (bad) abort(p, !p.isDead);
        }
    }

    // ------------------------------------------------------------------ player actions

    public static void onAction(EntityPlayerMP p, Net.Action a) {
        Battle b = ACTIVE.get(p.getUniqueID());
        if (b == null || b.awaitingDodge) return;
        EntityLiving mob = b.mob;
        if (mob.isDead || mob.getHealth() <= 0) { abort(p, true); return; }
        SoulType soul = SoulItem.getSoul(p);
        String name = mob.getName();
        String text;

        switch (a.type) {
            case Net.Action.FIGHT: {
                float acc = Math.max(0f, Math.min(1f, a.accuracy));
                float dmg = (float) p.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue();
                dmg = Math.max(1f, dmg) * (0.5f + 1.5f * acc);
                if (soul == SoulType.DETERMINATION) dmg *= 1.25f;
                mob.hurtResistantTime = 0;
                mob.attackEntityFrom(DamageSource.causePlayerDamage(p), dmg);
                if (mob.isDead || mob.getHealth() <= 0) { win(b, String.format("* You hit %s for %.1f damage!\n* YOU WON!", name, dmg)); return; }
                text = acc < 0.05f ? "* You missed!" : String.format("* You hit %s for %.1f damage!%s", name, dmg, acc > 0.9f ? " PERFECT!" : "");
                break;
            }
            case Net.Action.CHECK:
                text = String.format("* %s - ATK %.1f  HP %.1f/%.1f\n* Mercy: %d%%", name, enemyAttack(mob), mob.getHealth(), mob.getMaxHealth(), b.mercy);
                break;
            case Net.Action.CHEER: {
                int gain = soul == SoulType.JUSTICE ? 51 : 34;
                b.mercy = Math.min(100, b.mercy + gain);
                text = "* You cheer for " + name + ".\n* " + (b.mercy >= 100 ? name + " seems ready to be spared!" : "Mercy +" + gain + "%.");
                break;
            }
            case Net.Action.GUARD:
                b.guard = true;
                text = "* You brace yourself.\n* Next attack deals half damage.";
                break;
            case Net.Action.ITEM: {
                int slot = a.slot;
                ItemStack s = (slot >= 0 && slot < p.inventory.getSizeInventory()) ? p.inventory.getStackInSlot(slot) : ItemStack.EMPTY;
                if (s.isEmpty() || !(s.getItem() instanceof ItemFood)) { sendMenu(b, "* That item can't be used."); return; }
                float heal = ((ItemFood) s.getItem()).getHealAmount(s);
                p.heal(Math.max(1f, heal));
                text = "* You ate " + s.getDisplayName() + ".\n* Healed " + (int) Math.max(1f, heal) + " HP.";
                s.shrink(1);
                p.inventoryContainer.detectAndSendChanges();
                break;
            }
            case Net.Action.SPARE:
                if (b.mercy >= 100) {
                    SPARED.put(p.getUniqueID() + ":" + mob.getUniqueID(), p.world.getTotalWorldTime() + SPARE_TICKS);
                    p.addExperience(Math.max(1, (int) (mob.getMaxHealth() / 2)));
                    finish(b, Net.Update.SPARED, "* You spared " + name + ".\n* " + Math.max(1, (int) (mob.getMaxHealth() / 2)) + " XP gained.");
                    return;
                }
                text = "* " + name + " isn't ready to be spared.";
                break;
            case Net.Action.FLEE:
                finish(b, Net.Update.FLED, "* You got away safely!");
                return;
            default:
                return;
        }
        enemyTurn(b, text, soul);
    }

    public static void onDodge(EntityPlayerMP p, int hits) {
        Battle b = ACTIVE.get(p.getUniqueID());
        if (b == null || !b.awaitingDodge) return;
        b.awaitingDodge = false;
        hits = Math.max(0, Math.min(10, hits));
        float dmg = hits * b.perHit;
        b.guard = false;
        String text;
        if (dmg > 0) {
            p.hurtResistantTime = 0;
            applying = true;
            try {
                p.attackEntityFrom(DamageSource.causeMobDamage(b.mob), dmg);
            } finally {
                applying = false;
            }
            if (p.isDead || p.getHealth() <= 0) {
                ACTIVE.remove(p.getUniqueID());
                release(b);
                return; // vanilla death screen takes over on the client
            }
            text = String.format("* You took %.1f damage.", dmg);
        } else {
            text = "* You dodged everything!";
        }
        if (SoulItem.getSoul(p) == SoulType.KINDNESS) {
            p.heal(2f);
            text += "\n* Kindness heals 2 HP.";
        }
        sendMenu(b, text);
    }

    // ------------------------------------------------------------------ helpers

    private static float enemyAttack(EntityLiving mob) {
        return mob.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE) != null
                ? (float) mob.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue() : 2f;
    }

    private static void enemyTurn(Battle b, String text, SoulType soul) {
        b.turn++;
        b.awaitingDodge = true;
        float per = Math.max(1f, enemyAttack(b.mob) * 0.6f);
        if (b.guard) per *= 0.5f;
        if (soul == SoulType.INTEGRITY) per *= 0.75f;
        b.perHit = per;
        Net.Update u = new Net.Update(Net.Update.DODGE, text + "\n* " + b.mob.getName() + " attacks!",
                b.mob.getHealth(), b.player.getHealth(), b.player.getMaxHealth(), b.mercy);
        u.pattern = Math.floorMod(b.mob.getEntityId() + b.turn, 4);
        u.seed = new Random().nextInt();
        u.perHit = per;
        u.durMs = (int) (ENEMY_BASE_MS * (soul == SoulType.PATIENCE ? 0.75f : 1f));
        u.speedMul = soul == SoulType.PERSEVERANCE ? 0.8f : 1f;
        TurnBattleMod.NET.sendTo(u, b.player);
    }

    private static void sendMenu(Battle b, String text) {
        TurnBattleMod.NET.sendTo(new Net.Update(Net.Update.MENU, text, b.mob.getHealth(),
                b.player.getHealth(), b.player.getMaxHealth(), b.mercy), b.player);
    }

    private static void win(Battle b, String text) {
        finish(b, Net.Update.WON, text);
    }

    private static void finish(Battle b, int kind, String text) {
        ACTIVE.remove(b.player.getUniqueID());
        release(b);
        TurnBattleMod.NET.sendTo(new Net.Update(kind, text, Math.max(0, b.mob.getHealth()),
                b.player.getHealth(), b.player.getMaxHealth(), b.mercy), b.player);
    }
}
