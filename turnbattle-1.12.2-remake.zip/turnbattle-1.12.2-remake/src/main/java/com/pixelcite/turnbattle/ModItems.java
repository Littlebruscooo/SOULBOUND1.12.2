package com.pixelcite.turnbattle;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@Mod.EventBusSubscriber(modid = TurnBattleMod.MODID)
public class ModItems {
    public static final List<SoulItem> SOULS = new ArrayList<>();

    public static final CreativeTabs TAB = new CreativeTabs("turnbattle") {
        @Override
        @SideOnly(Side.CLIENT)
        public ItemStack getTabIconItem() {
            return new ItemStack(SOULS.isEmpty() ? net.minecraft.init.Items.DIAMOND : SOULS.get(0));
        }
    };

    static {
        for (SoulType t : SoulType.values()) SOULS.add(new SoulItem(t));
    }

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        for (SoulItem s : SOULS) event.getRegistry().register(s);
    }
}
