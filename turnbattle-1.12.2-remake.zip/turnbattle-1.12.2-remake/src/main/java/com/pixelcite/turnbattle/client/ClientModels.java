package com.pixelcite.turnbattle.client;

import com.pixelcite.turnbattle.ModItems;
import com.pixelcite.turnbattle.SoulItem;
import com.pixelcite.turnbattle.TurnBattleMod;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(modid = TurnBattleMod.MODID, value = Side.CLIENT)
public class ClientModels {
    @SubscribeEvent
    public static void models(ModelRegistryEvent e) {
        for (SoulItem s : ModItems.SOULS) {
            ModelLoader.setCustomModelResourceLocation(s, 0, new ModelResourceLocation(s.getRegistryName(), "inventory"));
        }
    }
}
