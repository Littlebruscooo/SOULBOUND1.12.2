package com.pixelcite.turnbattle;

import com.pixelcite.turnbattle.net.Net;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStoppingEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;

@Mod(modid = TurnBattleMod.MODID, name = "Soulbound Turn Battle (1.12.2 Remake)", version = "0.1.0",
        acceptedMinecraftVersions = "[1.12.2]")
public class TurnBattleMod {
    public static final String MODID = "turnbattle";
    public static SimpleNetworkWrapper NET;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        NET = NetworkRegistry.INSTANCE.newSimpleChannel(MODID);
        Net.register(NET);
        MinecraftForge.EVENT_BUS.register(new BattleEvents());
    }

    @Mod.EventHandler
    public void serverStopping(FMLServerStoppingEvent event) {
        Battles.clear();
    }
}
