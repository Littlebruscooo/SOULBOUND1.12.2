package com.pixelcite.turnbattle.client;

import com.pixelcite.turnbattle.net.Net;
import net.minecraft.client.Minecraft;

/** Client-only entry points called from packet handlers. */
public final class ClientHooks {
    private ClientHooks() {}

    public static void open(Net.Open m) {
        Minecraft.getMinecraft().displayGuiScreen(new GuiBattle(m));
    }

    public static void update(Net.Update u) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.currentScreen instanceof GuiBattle) {
            ((GuiBattle) mc.currentScreen).onUpdate(u);
        }
    }
}
