package com.pixelcite.turnbattle;

import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = TurnBattleMod.MODID)
public class ModSounds {
    public static final SoundEvent MUS_BATTLE = make("mus_battle_mob");
    public static final SoundEvent BATTLE_START = make("battle_start");
    public static final SoundEvent SLASH = make("slash");
    public static final SoundEvent DAMAGE = make("snd_damage");
    public static final SoundEvent HURT = make("snd_hurt");
    public static final SoundEvent SELECT = make("snd_select");
    public static final SoundEvent MENU_MOVE = make("snd_menumove");
    public static final SoundEvent ITEM = make("snd_item");
    public static final SoundEvent MERCY = make("snd_mercyadd");
    public static final SoundEvent DEFEAT = make("snd_defeat");
    public static final SoundEvent LEVEL_UP = make("snd_levelupmix");
    public static final SoundEvent TEXT = make("snd_text");
    public static final SoundEvent GRAZE = make("snd_graze");
    public static final SoundEvent POWER = make("snd_power");

    private static SoundEvent make(String name) {
        ResourceLocation rl = new ResourceLocation(TurnBattleMod.MODID, name);
        return new SoundEvent(rl).setRegistryName(rl);
    }

    @SubscribeEvent
    public static void register(RegistryEvent.Register<SoundEvent> event) {
        event.getRegistry().registerAll(MUS_BATTLE, BATTLE_START, SLASH, DAMAGE, HURT, SELECT, MENU_MOVE,
                ITEM, MERCY, DEFEAT, LEVEL_UP, TEXT, GRAZE, POWER);
    }
}
