package com.pixelcite.turnbattle.client;

import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.PositionedSound;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;

/** Looping, non-positional music track for the battle screen. */
public class BattleMusic extends PositionedSound {
    public BattleMusic(SoundEvent event) {
        super(event, SoundCategory.MUSIC);
        this.repeat = true;
        this.repeatDelay = 0;
        this.volume = 0.6F;
        this.attenuationType = ISound.AttenuationType.NONE;
    }
}
