package com.pixelcite.turnbattle;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class SoulItem extends Item {
    public final SoulType type;

    public SoulItem(SoulType type) {
        this.type = type;
        setRegistryName(TurnBattleMod.MODID, type.id + "_soul");
        setUnlocalizedName(TurnBattleMod.MODID + "." + type.id + "_soul");
        setMaxStackSize(1);
        setCreativeTab(ModItems.TAB);
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);
        if (!world.isRemote) {
            setSoul(player, type);
            player.sendStatusMessage(new TextComponentString("Soul equipped: " + type.id.substring(0, 1).toUpperCase() + type.id.substring(1)), true);
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, stack);
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void addInformation(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
        tooltip.add(I18n.format("item.turnbattle." + type.id + "_soul.desc"));
        tooltip.add("Right-click to equip");
    }

    // ---- equipped soul storage (survives death via Forge's persisted tag) ----
    private static final String KEY = "turnbattle_soul";

    public static void setSoul(EntityPlayer p, SoulType t) {
        NBTTagCompound data = p.getEntityData();
        NBTTagCompound persisted = data.getCompoundTag(EntityPlayer.PERSISTED_NBT_TAG);
        persisted.setString(KEY, t.id);
        data.setTag(EntityPlayer.PERSISTED_NBT_TAG, persisted);
    }

    /** The equipped soul, or null if the player has none. */
    @Nullable
    public static SoulType getSoul(EntityPlayer p) {
        NBTTagCompound persisted = p.getEntityData().getCompoundTag(EntityPlayer.PERSISTED_NBT_TAG);
        return SoulType.byId(persisted.getString(KEY));
    }
}
