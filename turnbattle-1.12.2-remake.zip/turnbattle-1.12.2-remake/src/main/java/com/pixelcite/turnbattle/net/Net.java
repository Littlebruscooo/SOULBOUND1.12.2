package com.pixelcite.turnbattle.net;

import com.pixelcite.turnbattle.Battles;
import com.pixelcite.turnbattle.client.ClientHooks;
import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

/** All packets for the battle. Client code is only touched inside the CLIENT handlers. */
public final class Net {
    private Net() {}

    public static void register(SimpleNetworkWrapper n) {
        n.registerMessage(Open.Handler.class, Open.class, 0, Side.CLIENT);
        n.registerMessage(Update.Handler.class, Update.class, 1, Side.CLIENT);
        n.registerMessage(Action.Handler.class, Action.class, 2, Side.SERVER);
        n.registerMessage(Dodge.Handler.class, Dodge.class, 3, Side.SERVER);
    }

    // ---------------- server -> client: open the battle screen ----------------
    public static class Open implements IMessage {
        public int mobId, soul, mercy;
        public float mobHp, mobMax, hp, hpMax;

        public Open() {}

        public Open(int mobId, float mobHp, float mobMax, float hp, float hpMax, int soul, int mercy) {
            this.mobId = mobId; this.mobHp = mobHp; this.mobMax = mobMax;
            this.hp = hp; this.hpMax = hpMax; this.soul = soul; this.mercy = mercy;
        }

        @Override public void toBytes(ByteBuf b) {
            b.writeInt(mobId); b.writeInt(soul); b.writeInt(mercy);
            b.writeFloat(mobHp); b.writeFloat(mobMax); b.writeFloat(hp); b.writeFloat(hpMax);
        }

        @Override public void fromBytes(ByteBuf b) {
            mobId = b.readInt(); soul = b.readInt(); mercy = b.readInt();
            mobHp = b.readFloat(); mobMax = b.readFloat(); hp = b.readFloat(); hpMax = b.readFloat();
        }

        public static class Handler implements IMessageHandler<Open, IMessage> {
            @Override public IMessage onMessage(Open m, MessageContext ctx) {
                Minecraft.getMinecraft().addScheduledTask(() -> ClientHooks.open(m));
                return null;
            }
        }
    }

    // ---------------- server -> client: state / enemy turn / end ----------------
    public static class Update implements IMessage {
        /** kinds: 0 back to menu, 1 enemy turn (dodge), 2 won, 3 spared, 4 fled, 5 lost, 6 abort (close now) */
        public static final int MENU = 0, DODGE = 1, WON = 2, SPARED = 3, FLED = 4, LOST = 5, ABORT = 6;

        public int kind, mercy, pattern, seed, durMs;
        public String text = "";
        public float mobHp, hp, hpMax, perHit, speedMul = 1f;

        public Update() {}

        public Update(int kind, String text, float mobHp, float hp, float hpMax, int mercy) {
            this.kind = kind; this.text = text; this.mobHp = mobHp; this.hp = hp; this.hpMax = hpMax; this.mercy = mercy;
        }

        @Override public void toBytes(ByteBuf b) {
            b.writeInt(kind); b.writeInt(mercy); b.writeInt(pattern); b.writeInt(seed); b.writeInt(durMs);
            ByteBufUtils.writeUTF8String(b, text);
            b.writeFloat(mobHp); b.writeFloat(hp); b.writeFloat(hpMax); b.writeFloat(perHit); b.writeFloat(speedMul);
        }

        @Override public void fromBytes(ByteBuf b) {
            kind = b.readInt(); mercy = b.readInt(); pattern = b.readInt(); seed = b.readInt(); durMs = b.readInt();
            text = ByteBufUtils.readUTF8String(b);
            mobHp = b.readFloat(); hp = b.readFloat(); hpMax = b.readFloat(); perHit = b.readFloat(); speedMul = b.readFloat();
        }

        public static class Handler implements IMessageHandler<Update, IMessage> {
            @Override public IMessage onMessage(Update m, MessageContext ctx) {
                Minecraft.getMinecraft().addScheduledTask(() -> ClientHooks.update(m));
                return null;
            }
        }
    }

    // ---------------- client -> server: a menu choice ----------------
    public static class Action implements IMessage {
        public static final int FIGHT = 0, CHECK = 1, CHEER = 2, GUARD = 3, ITEM = 4, SPARE = 5, FLEE = 6;

        public int type, slot;
        public float accuracy;

        public Action() {}

        public Action(int type, float accuracy, int slot) {
            this.type = type; this.accuracy = accuracy; this.slot = slot;
        }

        @Override public void toBytes(ByteBuf b) { b.writeInt(type); b.writeInt(slot); b.writeFloat(accuracy); }
        @Override public void fromBytes(ByteBuf b) { type = b.readInt(); slot = b.readInt(); accuracy = b.readFloat(); }

        public static class Handler implements IMessageHandler<Action, IMessage> {
            @Override public IMessage onMessage(Action m, MessageContext ctx) {
                EntityPlayerMP p = ctx.getServerHandler().player;
                p.getServerWorld().addScheduledTask(() -> Battles.onAction(p, m));
                return null;
            }
        }
    }

    // ---------------- client -> server: result of the dodge phase ----------------
    public static class Dodge implements IMessage {
        public int hits;

        public Dodge() {}
        public Dodge(int hits) { this.hits = hits; }

        @Override public void toBytes(ByteBuf b) { b.writeInt(hits); }
        @Override public void fromBytes(ByteBuf b) { hits = b.readInt(); }

        public static class Handler implements IMessageHandler<Dodge, IMessage> {
            @Override public IMessage onMessage(Dodge m, MessageContext ctx) {
                EntityPlayerMP p = ctx.getServerHandler().player;
                p.getServerWorld().addScheduledTask(() -> Battles.onDodge(p, m.hits));
                return null;
            }
        }
    }
}
