package com.pixelcite.turnbattle;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.DamageSource;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class BattleEvents {

    /** Hitting a hostile mob starts a battle. Sneak while attacking to fight normally. */
    @SubscribeEvent
    public void onAttack(AttackEntityEvent e) {
        EntityPlayer p = e.getEntityPlayer();
        if (p.world.isRemote || !(p instanceof EntityPlayerMP) || p instanceof FakePlayer) return;
        EntityPlayerMP sp = (EntityPlayerMP) p;
        if (Battles.inBattle(sp)) {
            e.setCanceled(true);
            return;
        }
        if (p.isSneaking()) return;
        Entity t = e.getTarget();
        if (Battles.eligible(sp, t)) {
            e.setCanceled(true);
            Battles.start(sp, (EntityLiving) t);
        }
    }

    /** A hostile mob hitting you also starts a battle. Players in battle are untouchable. */
    @SubscribeEvent
    public void onHurt(LivingAttackEvent e) {
        if (!(e.getEntityLiving() instanceof EntityPlayerMP) || e.getEntityLiving() instanceof FakePlayer) return;
        EntityPlayerMP p = (EntityPlayerMP) e.getEntityLiving();
        if (p.world.isRemote || Battles.applying) return;
        DamageSource src = e.getSource();
        if (Battles.inBattle(p)) {
            if (src != DamageSource.OUT_OF_WORLD) e.setCanceled(true);
            return;
        }
        Entity attacker = src.getTrueSource();
        if (attacker == null) return;
        if (Battles.isSpared(p, attacker)) {
            e.setCanceled(true);
            return;
        }
        if (Battles.eligible(p, attacker)) {
            e.setCanceled(true);
            Battles.start(p, (EntityLiving) attacker);
        }
    }

    @SubscribeEvent
    public void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.player instanceof EntityPlayerMP) Battles.abort((EntityPlayerMP) e.player, false);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase == TickEvent.Phase.END) Battles.tick();
    }
}
