package com.pixelcite.turnbattle;

/** The seven soul traits. Each maps to an item and the sprite shown during the dodge phase. */
public enum SoulType {
    DETERMINATION("determination", "redsoulsimple"),
    BRAVERY("bravery", "orangesoulsimple"),
    INTEGRITY("integrity", "bluesoulsimple"),
    JUSTICE("justice", "yellowsoulsimple"),
    KINDNESS("kindness", "greensoulsimple"),
    PATIENCE("patience", "cyansoulsimple"),
    PERSEVERANCE("perseverance", "purplesoulsimple");

    public final String id;
    public final String texture;

    SoulType(String id, String texture) {
        this.id = id;
        this.texture = texture;
    }

    public static SoulType byId(String id) {
        for (SoulType t : values()) if (t.id.equals(id)) return t;
        return null;
    }

    public static SoulType byOrdinal(int i) {
        return (i < 0 || i >= values().length) ? null : values()[i];
    }
}
